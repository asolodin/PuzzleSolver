import os
from collections import defaultdict
from typing import Any

import openai
from dotenv import load_dotenv

from rlm.clients.base_lm import BaseLM
from rlm.core.types import ModelUsageSummary, UsageSummary

load_dotenv()

# Load API keys from environment variables
DEFAULT_OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
DEFAULT_OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")
DEFAULT_VERCEL_API_KEY = os.getenv("AI_GATEWAY_API_KEY")
DEFAULT_PRIME_API_KEY = os.getenv("PRIME_API_KEY")
DEFAULT_PRIME_INTELLECT_BASE_URL = "https://api.pinference.ai/api/v1/"


class OpenAIResponseClient(BaseLM):
    """
    LM client for the OpenAI Responses API using client-managed context.

    Any additional keyword arguments (e.g. default_headers, default_query, max_retries)
    are passed through to the underlying openai.OpenAI and openai.AsyncOpenAI constructors.
    Only model_name is excluded, since it is not a client constructor argument.
    """

    def __init__(
        self,
        api_key: str | None = None,
        model_name: str | None = None,
        base_url: str | None = None,
        **kwargs,
    ):
        super().__init__(model_name=model_name, **kwargs)

        if api_key is None:
            if base_url == "https://api.openai.com/v1" or base_url is None:
                api_key = DEFAULT_OPENAI_API_KEY
            elif base_url == "https://openrouter.ai/api/v1":
                api_key = DEFAULT_OPENROUTER_API_KEY
            elif base_url == "https://ai-gateway.vercel.sh/v1":
                api_key = DEFAULT_VERCEL_API_KEY
            elif base_url == DEFAULT_PRIME_INTELLECT_BASE_URL:
                api_key = DEFAULT_PRIME_API_KEY

        client_kwargs = {
            "api_key": api_key,
            "base_url": base_url,
            "timeout": self.timeout,
            **{k: v for k, v in self.kwargs.items() if k != "model_name"},
        }
        self.client = openai.OpenAI(**client_kwargs)
        self.async_client = openai.AsyncOpenAI(**client_kwargs)
        self.model_name = model_name
        self.base_url = base_url

        # Per-model usage tracking
        self.model_call_counts: dict[str, int] = defaultdict(int)
        self.model_input_tokens: dict[str, int] = defaultdict(int)
        self.model_output_tokens: dict[str, int] = defaultdict(int)
        self.model_total_tokens: dict[str, int] = defaultdict(int)
        self.model_costs: dict[str, float] = defaultdict(float)  # Cost in USD

        self.last_prompt_tokens = 0
        self.last_completion_tokens = 0
        self.last_cost: float | None = None

    def completion(self, prompt: str | list[dict[str, Any]], model: str | None = None) -> str:
        input_payload = self.normalize_input(prompt)
        model = model or self.model_name
        if not model:
            raise ValueError("Model name is required for OpenAIResponseClient.")

        request_kwargs: dict[str, Any] = {"model": model, "input": input_payload}
        if self.client.base_url == DEFAULT_PRIME_INTELLECT_BASE_URL:
            request_kwargs["extra_body"] = {"usage": {"include": True}}

        response = self.client.responses.create(**request_kwargs)
        self.track_cost(response, model)
        return self.extract_text_output(response)

    async def acompletion(
        self, prompt: str | list[dict[str, Any]], model: str | None = None
    ) -> str:
        input_payload = self.normalize_input(prompt)
        model = model or self.model_name
        if not model:
            raise ValueError("Model name is required for OpenAIResponseClient.")

        request_kwargs: dict[str, Any] = {"model": model, "input": input_payload}
        if self.client.base_url == DEFAULT_PRIME_INTELLECT_BASE_URL:
            request_kwargs["extra_body"] = {"usage": {"include": True}}

        response = await self.async_client.responses.create(**request_kwargs)
        self.track_cost(response, model)
        return self.extract_text_output(response)

    def normalize_input(self, prompt: str | list[dict[str, Any]]) -> str | list[dict[str, Any]]:
        if isinstance(prompt, str):
            return prompt
        if isinstance(prompt, list) and all(isinstance(item, dict) for item in prompt):
            return prompt
        raise ValueError(f"Invalid prompt type: {type(prompt)}")

    def get_field(self, obj: Any, field: str) -> Any:
        if isinstance(obj, dict):
            return obj.get(field)
        return getattr(obj, field, None)

    def extract_text_output(self, response: Any) -> str:
        output_text = self.get_field(response, "output_text")
        if isinstance(output_text, str) and output_text:
            return output_text

        output_items = self.get_field(response, "output")
        if not isinstance(output_items, list):
            raise ValueError("No text output returned from Responses API.")

        text_parts: list[str] = []
        for item in output_items:
            if self.get_field(item, "type") != "message":
                continue
            content = self.get_field(item, "content")
            if not isinstance(content, list):
                continue
            for part in content:
                if self.get_field(part, "type") != "output_text":
                    continue
                text = self.get_field(part, "text")
                if isinstance(text, str) and text:
                    text_parts.append(text)

        if text_parts:
            return "\n\n".join(text_parts)

        raise ValueError("No text output returned from Responses API.")

    def track_cost(self, response: Any, model: str):
        self.model_call_counts[model] += 1

        usage = self.get_field(response, "usage")
        if usage is None:
            raise ValueError("No usage data received. Tracking tokens not possible.")

        input_tokens = self.get_field(usage, "input_tokens")
        output_tokens = self.get_field(usage, "output_tokens")
        total_tokens = self.get_field(usage, "total_tokens")
        if input_tokens is None or output_tokens is None or total_tokens is None:
            raise ValueError("Incomplete usage data received. Tracking tokens not possible.")

        self.model_input_tokens[model] += int(input_tokens)
        self.model_output_tokens[model] += int(output_tokens)
        self.model_total_tokens[model] += int(total_tokens)

        # Track last call for handler to read
        self.last_prompt_tokens = int(input_tokens)
        self.last_completion_tokens = int(output_tokens)

        # Extract cost from providers that include it in usage metadata
        self.last_cost = None
        cost = self.get_field(usage, "cost")
        if cost is None:
            extra = self.get_field(usage, "model_extra")
            if isinstance(extra, dict):
                if extra.get("cost"):
                    cost = extra["cost"]
                elif extra.get("cost_details", {}).get("upstream_inference_cost"):
                    cost = extra["cost_details"]["upstream_inference_cost"]

        if cost is not None and float(cost) > 0:
            self.last_cost = float(cost)
            self.model_costs[model] += self.last_cost

    def get_usage_summary(self) -> UsageSummary:
        model_summaries = {}
        for model in self.model_call_counts:
            cost = self.model_costs.get(model)
            model_summaries[model] = ModelUsageSummary(
                total_calls=self.model_call_counts[model],
                total_input_tokens=self.model_input_tokens[model],
                total_output_tokens=self.model_output_tokens[model],
                total_cost=cost if cost else None,
            )
        return UsageSummary(model_usage_summaries=model_summaries)

    def get_last_usage(self) -> ModelUsageSummary:
        return ModelUsageSummary(
            total_calls=1,
            total_input_tokens=self.last_prompt_tokens,
            total_output_tokens=self.last_completion_tokens,
            total_cost=self.last_cost,
        )
